
############Creating Dictionary################

friends = {
'tom' : '111-222-333',
'jerry' : '666-33-111'
}
print(friends) #{'tom': '111-222-333', 'jerry': '666-33-111'}

########Retrieving, modifying and adding elements in the dictionary##############


friends = {'tom' : '111-222-333','jerry' : '666-33-111'}
print(friends) #{'tom': '111-222-333', 'jerry': '666-33-111'}

#Retrieving elements from the dictionary
print(friends['tom']) # 111-222-333

#Adding elements into the dictionary
friends['bob'] = '888-999-666'
print(friends) #{'tom': '111-222-333', 'jerry': '666-33-111', 'bob': '888-999-666'}

#Modify elements into the dictionary
friends['bob'] = '888-999-777'
print(friends) #{'tom': '111-222-333', 'jerry': '666-33-111', 'bob': '888-999-777'}

#Delete element from the dictionary
del friends['bob']
print(friends) #{'tom': '111-222-333', 'jerry': '666-33-111'}


########################Looping items in the dictionary ###################################

friends = {'a' : '100',
           'b' : '200',
           'c' :'300',
           'd' : '400'
           }
for x in friends:
    print(x, ":", friends[x])

	
######################## Find the length of the dictionary #####################
friends = {'a' : '100',
           'b' : '200',
           'c' :'300',
           'd' : '400'
           }
print(len(friends)) #4

########### Equality Tests in dictionary###################
	
d1 = {"mike":41, "bob":3}
d2 = {"bob":3, "mike":41}

print(d1 == d2) #True
print(d1 != d2) # False	
	

	
#################Dictionary methods#######################################
	
friends = {'tom': '111-222-333', 'bob': '888-999-666', 'jerry': '666-33-111'}

#popitem()	Returns randomly select item from dictionary and also remove the selected item.
print(friends.popitem()) #('jerry', '666-33-111')

#clear()	Delete everything from dictionary
print(friends.clear()) #None

friends = {'tom': '111-222-333', 'bob': '888-999-666', 'jerry': '666-33-111'}

#keys()	Return keys in dictionary as tuples
print(friends.keys()) #dict_keys(['tom', 'bob', 'jerry'])

#values()	Return values in dictionary as tuples
print(friends.values()) #dict_values(['111-222-333', '888-999-666', '666-33-111'])

#get(key) Return value of key, if key is not found it returns None, instead on throwing KeyError exception
print(friends.get('tom')) #111-222-333

#pop(key) Remove the item from the dictionary, if key is not found KeyError will be thrown
print(friends.pop('bob')) #888-999-666
print(friends) #{'tom': '111-222-333', 'jerry': '666-33-111'}
	
	
