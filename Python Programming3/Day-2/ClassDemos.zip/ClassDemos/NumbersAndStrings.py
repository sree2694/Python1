#======= Python Numbers ======================================

# Number Types & conversions

#Example1:
x=10  # int
y="welcome"  #string
z=True   #boolean
w=10.5  #float

print(type(x))
print(type(y))
print(type(z))
print(type(w))

#Example2:
x=10  # int
y="welcome"  #string
z=True   #boolean
w=10.5  #float

print(type(float(x)))  # valid   int --> float
print(type(int(w)))   # valid  float --> int

print(type(int(z)))   # valid  boolean --> int
print(type(float(z)))  # valid  boolean --> float

print(type(int(y))) # invalid
print(type(float(y)))  # invalid



#======= max() and min()functions on Numbers =========
print("max of 80, 100, 1000:", max(80, 100, 1000))
print("max of -10, 10, 5:", max(-10, 10, 5))

print("min of 80, 100, 1000:", min(80, 100, 1000))
print("min of -10, 10, 5:", min(-10, 10, 5))

#=====================Pythin Strings=================================

#Creating strings
name = "John" # a string
mychar = 'S' # a character
print(name)
print(mychar)

#you can also use the following syntax to create strings.
name1 = str() # this will create empty string object
name2 = str("newstring") # string object containing 'newstring'
print(name1)
print(name2)

#========Strings are immutable=========================
str1="welcome"
str2="welcome"

print(id(str1),id(str2))  #57660416 ,57660416

str2=str2+"to python"
print(id(str1),id(str2))  #57660416 ,59955200(changed means immutable)



#==========  + and * with string========================
str="welcome"
print(str+" to Python programming") # welcome to Python programming
print(str *3) #welcomewelcomewelcome


#============Slicing==============
str="welcome"
print(str[1:3]) #el
print(str[:6])#welcom
print(str[4:])#ome
print(str[1:-1]) #elcom #elimate 1 char from end
print(str[1:-2]) #elco  #eleminate 2 chars from end

#============ord() and chr() Functions==============

print(ord('A')) #65
print(chr(65)) #A

#=============String Functions in Python==========
print(len("hello")) #5
print(max("abc")) #c
print(min("abc")) #a


#===================in  and not in  operators=====
s1 = "Welcome"
print("come" in s1)# True
print("come" not in s1) #False

#==============Strings comparison================
print("tim" == "tie") #False
print("free" != "freedom") #True
print ("arrow" > "aron") #True
print ("right" >= "left") #True
print ("teeth" < "tee") #False
print ("yellow" <= "fellow") #False
print ("abc" > "") #True

#=============Iterating string using for loop==================
s = "hello"
for i in s:
    #print(i)
    #print(s, end="\n")  #this is default behavior
    #print(s, end="")    # print string without a newline
    #print(s, end="foo")  # now print() will print foo after every string

#===============Testing strings====================
s = "welcome to python"
print(s.isalnum()) #False
print("Welcome".isalpha()) #True
print("2012".isdigit()) #True
print("first Number".isidentifier())#False
print(s.islower()) #True
print("WELCOME".isupper()) #True
print(" ".isspace()) #True


#===========Searching for Substrings==================

s = "welcome to python"
print(s.endswith("thon")) #True
print(s.startswith("good")) #False
print(s.find("come")) #3
print(s.find("become")) #-1
print(s.count("o")) #3

#===============Converting Strings================
s = "String in PYTHON"
s1 = s.capitalize()
print(s1) #String in python

s2 = s.title()
print(s2)#String In Python

s3 = s.lower()
print(s3) #string in python

s4 = s.upper()
print(s4) #STRING IN PYTHON

s5 = s.swapcase()
print(s5) #sTRING IN python

s6 = s.replace("in", "on")
print(s6) #String on PYTHON

print(s) #String in PYTHON











