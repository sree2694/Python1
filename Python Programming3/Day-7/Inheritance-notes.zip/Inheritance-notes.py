#### Example1:  Inheritance Example- basic
class A:
    def m1(self):
        print("This is m1 method from class A")

class B(A):
    def m2(self):
        print("This is m2 method from class B")

bobj=B()
bobj.m1() # calling m1 from A
bobj.m2() # calling m2 from B



########################### Types of inheritnaces #############################################################

#### Example 2:  Single inheritance
class A:
    x,y=10,20
    def m1(self):
        print(self.x+self.y)
class B(A):
    a,b=100,200
    def m2(self):
        print(self.a+self.b)

bobj=B()
bobj.m1()
bobj.m2()

###### Example3:  Multilevel inheritance
class A:
    x,y=10,20
    def m1(self):
        print(self.x+self.y)
class B(A):
    a,b=100,200
    def m2(self):
        print(self.a+self.b)

class C(B):
    i,j=1,2
    def m3(self):
        print(self.i+self.j)

cobj=C()
cobj.m1()
cobj.m2()
cobj.m3()


####### Example 4: Heirarchy inheritance
class A:
    x,y=10,20
    def m1(self):
        print(self.x+self.y)
class B(A):
    a,b=100,200
    def m2(self):
        print(self.a+self.b)

class C(A):
    i,j=1,2
    def m3(self):
        print(self.i+self.j)

bobj=B()
bobj.m1()
bobj.m2()

cobj=C()
cobj.m1()
cobj.m3()

######## EXAMPLE 5: Multiple inheritance
class A:
    x,y=10,20
    def m1(self):
        print(self.x+self.y)
class B:
    a,b=100,200
    def m2(self):
        print(self.a+self.b)

class C(A,B):
    i,j=1,2
    def m3(self):
        print(self.i+self.j)

cobj=C()
cobj.m1()
cobj.m2()
cobj.m3()

######################       super()           ######################################################

#### ##### Inheritance Example6  : calling parent class method using super() 
class A:
    def m1(self):
        print("This is m1 method from class A")

class B(A):
    def m2(self):
        print("This is m2 method from class B")
        super().m1() # calling parent class method using super() 

bobj=B()
bobj.m2() # calling m2 from B

######## Inheritance Example7  : Calling parent class variables (names are different)

class A:
    a,b=10,20

class B(A):
    i,j=100,200
    def m2(self,x,y):
        print(x+y) # local variables # 3000
        print(self.i+self.j) # Child class variables # 300
        print(self.a+self.b) # Parent class varaibles # 30

bobj=B()
bobj.m2(1000,2000) # calling m2 from B

########### Inheritance Example8  : calling parent class variables using super()(names are same)

a,b=1,2
class A:
    a,b=10,20

class B(A):
    a,b=100,200
    def m2(self,a,b):
        print(a+b) # local variables # 3000
        print(self.a+self.b) # Child class variables # 300
        print(super().a+super().b) # Parent class varaibles # 30
        print(globals()['a'] + globals()['b'])  # global varaibles # 3

bobj=B()
bobj.m2(1000,2000) # calling m2 from B


######## Inheritance Example9  : calling parent class constructor when child class has No constructor

class A:
    def __init__(self):
        print("constructor from class A")

class B(A):
    pass

bobj=B() # Executes parent class constructor

########## Inheritance Example 10  : calling child class constructor by default even thou parent is having constructor

class A:
    def __init__(self):
        print("constructor from class A")

class B(A):
    def __init__(self):
        print("constructor from class B")

bobj=B() # Executes Child class constructor



########## Inheritance Example11  : calling parent class constructor from child class construcctor using super()
class A:
    def __init__(self):
        print("constructor from class A")

class B(A):
    def __init__(self):
        print("constructor from class B")
        super().__init__() # calls parent class constructor -Approach1
        A.__init__(self)  # calls parent class constructor -Approach2

bobj=B() # Executes Child class constructor


##################### More Examples ###############################################

##############Example 12:   

class Parent:
    def __init__(self,first,last):
        self.first=first
        self.last=last

class Child(Parent):
    def __init__(self,first,last,id):
        #self.first = first
        #self.last = last
        super().__init__(first,last) # Here we can send first,last to parant class constructor

        self.id=id

    def display(self):
        print("EmpID:{}  FirstName:{}  LastName:{}".format(self.id,self.first,self.last))

c1=Child("pavan","kumar",101)
c1.display()


############Example - Same as Example 12,  Here used __str__()

class Parent:
    def __init__(self,first,last):
        self.first=first
        self.last=last

class Child(Parent):
    def __init__(self,first,last,id):
        #self.first = first
        #self.last = last
        super().__init__(first,last) # Here we can send first,last to parant class constructor

        self.id=id

    def __str__(self):
        return("EmpID:{}  FirstName:{}  LastName:{}".format(self.id,self.first,self.last))

c1=Child("pavan","kumar",101)
print(c1)







