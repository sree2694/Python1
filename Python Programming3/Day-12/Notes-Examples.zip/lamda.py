x = lambda a : a + 10
print(x(5))  # Passing single variable

x = lambda a, b : a * b
print(x(5, 6))  # passing multiple variables


x = lambda a, b, c : a + b + c
print(x(5, 6, 2))