# Print keywords supported by Python 3.x
import keyword
print(keyword.kwlist)