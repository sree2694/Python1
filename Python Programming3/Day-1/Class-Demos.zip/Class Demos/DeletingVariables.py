a=10
print(a)

del a    # deletes the variable

print(a)  #NameError: name 'a' is not defined