#num1=input("Enter first number:")
#num2=input("Enter second number:")

#print(num1+num2) #1020


#Apprach1
#num1= int(input("Enter first number:"))
#num2=int(input("Enter second number:"))

#print(num1+num2) #30


#Apprach2
#num1= input("Enter first number:")
#num2=input("Enter second number:")
#print(int(num1)+int(num2))  #30


num1=int(input("Enter first number:"))
num2=float(input("Enter second number:"))

print(num1+num2)


