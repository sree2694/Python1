# Single Line comment
# Single Line comment
# Single Line comment

"""Multi
Line
Comment"""

'''Multi
Line
Comment'''

print (10)
