
###############    Example#1  ################

a=10
b=10.5
name='pavan'
print(a)
print(b)
print(name)
print(a,b,name)

###############    Example#2  ################

#this statement assign 100 to a, 100.5 to b and Welcome to c. Multiple Values to multiple varaibles
a,b,c=100,100.5,"welcome"
print(a,b,c)


###############    Example#3  ################


a = b = c = 100 # this statement assign 100 to c, b and a.  Single value to all variables
print(a,b,c)


###############    Example#4  ################
x = 1
y = 2
y, x = x, y  # assign y value to x and x value to y
print (x,y)

