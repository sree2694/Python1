
print(10+10) # valid
print(10.5+10.5) # valid
print("welcome"+"python") # valid
print (10+15.5) # valid

print(True+5) # valid
print(10+False) # valid
print(True+True)# valid

print(10+"welcome")  #Not valid  -TypeError: unsupported operand type(s)
print(10.5+"welcome")  #Not valid -TypeError: unsupported operand type(s)
print(True+"welcome")  #Not valid -TypeError: unsupported operand type(s)

