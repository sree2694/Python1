
x=100  # int type
y=10.5 # float type

s1="welcome"  # string/char type
s2='welcome' # string /char type

b=  True # boolean type

# To know th type of variables
print(type(x))
print(type(y))
print(type(s1))
print(type(s2))
print(type(b))





