# swapping
x=10
y=5

print("Before swapping values are:",x,y)

x,y=y,x

print("After swapping values are:",x,y)

