########Creating functions

def myfunc():
    pass

def sum(start, end):
    result = 0
    for i in range(start, end + 1):
        result += i
    print(result)

myfunc()
sum(10, 50)

##########Function with return value.

def sum(start, end):
    result = 0
    for i in range(start, end + 1):
        result += i
    return result

s = sum(10, 50)
print(s)

########You can also use the return statement without a return value.

def sum(start, end):
    if (start > end):
        print("start should be less than end")
        return  # here we are not returning any value so a special value None is returned
    result = 0
    for i in range(start, end + 1):
        result += i
    return result

s = sum(110, 50)
print(s)


####In python if you do not explicitly return value from a function , then a special value  None  is always returned. 

def test():   # test function with only one statement
    i = 100
	
print(test()) #None


######################## Global variables vs local variables ##########

#Example:1
#--------------

global_var = 12  # a global variable

def func():
    local_var = 100  # this is local variable
    print(global_var)  # you can access global variables in side function


func()  # calling function func()
#print(local_var) # you can't access local_var outside the function - NameError: name 'local_var' is not defined


#Example:2
#------------------
xy = 100

def cool():
    xy = 200  # xy inside the function is totally different from xy outside the function
    print(xy)  # this will print local xy variable i.e 200

cool()
print(xy) # this will print global xy variable i.e 100


######### Using Global variable as Local variable

#Example:3
#----------------
t = 1

def increment():
    global t  # now t inside the function is same as t outside the function
    t = t + 1
    print(t)  # Displays 2

increment()
print(t)  # Displays 2

#Example:4 :you can’t assign a value to variable while declaring them global .
#---------------
t = 1
def increment():
    # global t = 1   # this is error
    global t
    t = 100  # this is okay
    t = t + 1
    print(t)  # Displays 101

increment() #101
print(t)  # Displays 101


#Example:5 : There is no need to declare global variables outside the function. 
# You can declare them global inside the function.

def foo():
    global x  # x is declared as global so it is available outside the function
    x = 100
    print(x)

foo()
print(x)


###########  Passing Arguments #######################

#Example:1: Passing Arguments with default values(positional)
#---------------
def func(i, j = 100):
    print(i, j) #2 100   #2 300

func(2) # here no value is passed to j, so default value will be used
func(2, 300) # here 300 is passed as a value of j, so default value will not be used

#Example:2: Keyword arguments
#---------------
def named_args(name, greeting):
    print(greeting + " " + name )

named_args(name='jim', greeting='Hello')

named_args(greeting='Hello', name='jim') # you can pass arguments this way too


#Example:3: Mixing Positional and Keyword Arguments
#---------------

def my_func(a, b, c):
    print(a, b, c)

# using positional arguments only
my_func(12, 13, 14)

# here first argument is passed as positional arguments while other two as keyword argument
my_func(12, b=13, c=14)

# same as above
my_func(12, c=13, b=14)

# this is wrong as positional argument must appear before any keyword argument
# my_func(12, b=13, 14)

#################### Returning multiple values from Function #########################

def bigger(a, b):
    if a > b:
        return a, b
    else:
        return b, a

s = bigger(12, 100)
print(s)
print(type(s))





















