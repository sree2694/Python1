############# Example 1: Program without try-except

print("Program started")
print (10/0)

print("Program in progress")
print("Program completed")

############# Example 2: Program with try-except

print("Program started")
try:
    print (10/0)
except ZeroDivisionError as e:
    print("Entered in except block - Handled Exception")
print("Program in progress")
print("Program completed")


############# Example 3: Multi except blocks...else..finally 

try:
    num1, num2 = 10,5
    result = num1 / num2
    print("Result is", result)

except ZeroDivisionError:
    print("Division by zero is error !!")

except SyntaxError:
    print("Comma is missing. Enter numbers separated by comma like this 1, 2")

except:
    print("Wrong input")

else:
    print("No exceptions")

finally:
    print("This will execute no matter what")
	
	
	
###################Example 4: #Raising exceptions

def enterage(age):
    if age < 0:
        raise ValueError("Only positive integers are allowed")

    if age % 2 == 0:
        print("age is even")
    else:
        print("age is odd")

try:
    num = 0
    enterage(num)

except ValueError:
    print("Only positive integers are allowed")
except:
    print("something is wrong")
	
	
	
	
###################Example 5: #Using Exception objects
	
try:
    number = one
    print("The number is", number)
except NameError as ex:
    print("Exception:", ex)
	
	
	
	
	
