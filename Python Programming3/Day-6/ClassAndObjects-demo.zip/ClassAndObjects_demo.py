####Example-1

class MyClass:
    def myfunc(self):
        pass

    def display(self,name):
        print("Name is:",name)

mc=MyClass()
mc.myfunc()
mc.display('scott')

####Example-2 : Instance method & Static mehod

class MyClass:
    def m1(self):
        print("instance method")

    @staticmethod
    def m2():
        print("static method")

mc=MyClass()
mc.m1() # Calling instance method
MyClass.m2()  # Calling static method directly using class name

####Example-3 : Static mehod with parameters
class MyClass:
    def m1(self):
        print("instance method")

    @staticmethod
    def m2(self):
        print(self)

mc=MyClass()
mc.m1() # Calling instance method
MyClass.m2(10)  # Calling static method directly using class name

#####Example4: Declaring varaibles inside the class
			# To represent  class varaibles we need to use self keyword

class MyClass:
    a,b=10,20

    def add(self):
        print(self.a+self.b)

    def mul(self):
        print(self.a * self.b)

cal=MyClass()
cal.add()
cal.mul()


#####Example5: Local variables, Class variables & Global Variables  (Different Names)

i,j=15,25  # Global variables
class MyClass:
    a,b=10,20  # class varaibles
    def add(self,x,y): # Local variables
        print(x+y) # accessing local variables
        print(self.a+self.b)  # accessing class varibles
        print(i+j) # accessing global variables
cal=MyClass()
cal.add(100,200)


#####Example6: Local variables, Class variables & Global Variables  (Same variable Names)

a,b=15,25  # Global variables
class MyClass:
    a,b=10,20  # class varaibles
    def add(self,a,b): # Local variables
        print(a+b) # accessing local variables
        print(self.a+self.b)  # accessing class varibles
        print(globals()['a']+globals()['b']) # accessing global variables
cal=MyClass()
cal.add(100,200)

####Example 7: One class - Multiple Objects
class MyClass:
    def display(self):
        print(" this is display method")

obj1=MyClass()
obj1.display()

obj2=MyClass()
obj2.display()



#####Example 8: Named Object & Nameless object
class MyClass:
    def display(self):
        print(" this is display method")

obj1=MyClass()  # Named Object
obj1.display()

MyClass().display() # Nameless Object

#####Example9:  Checking memory locations of Objects

class MyClass:
    def m1(self):
        pass

c1=MyClass()
c2=MyClass()
c3=c1

print(id(c1))  # Same as c3
print(id(c2))
print(id(c3)) # same as c1

print(c1 is c2)
print(c3 is c1)
print(c1 is not c2)
print(c3 is not c1)

###########################################################################################################################

#######Example10: Declaring constructor inside the class
 
class MyClass():
    def m1(self):
        print("good morning")

    def __init__(self):  # constructor within the class
        print("This is constructor")

c=MyClass()
c.m1()

########## Example11:converting local variables in to class variables (Here Method taking arguments)
class MyClass:
    def values(self ,val1,val2):
        print(val1)
        print(val2)
        self.val1=val1 # converting local varaibles in to class variables
        self.val2=val2

    def add(self):
        print(self.val1+self.val2)
    def mul(self):
        print(self.val1 * self.val2)

mc=MyClass()
mc.values(10,20)
mc.add()
mc.mul()

##########Example12:converting local variables in to class variables (Here Constructor taking arguments)
class MyClass:
    def __init__(self ,val1,val2):
        print(val1)
        print(val2)
        self.val1=val1 # converting local varaibles in to class variables
        self.val2=val2
    def add(self):
        print(self.val1+self.val2)
    def mul(self):
        print(self.val1 * self.val2)

mc=MyClass(10,20)
mc.add()
mc.mul()



############## Example 13: Calling Current Class method in another method

class MyClass:
    def m1(self):
        print(" this is m1 method")
        self.m2(100)
    def m2(self,a):
        print("this is m2 method", a)

mc=MyClass()
mc.m1()


########Example 14: Constructor with arguments
class MyClass:
    name="pavan"

    def __init__(self,name):
        print(name) # constructor argument is local #Kumar
        print(self.name) # accessing class variable # pavan

mc=MyClass("Kumar")



########### Example15:   
#Requirement:
# Class Name : Emp
# Constructor: Accepts eid, ename, sal
# display method: prints eid, ename & sal

class Emp:
    def __init__(self,eid,ename,sal):
        self.eid=eid
        self.ename=ename
        self.sal=sal
    def display(self):
        print("emp id:{} emp name:{}  emp sal:{}".format(self.eid,self.ename,self.sal))
        print("emp id:%d emp name:%s  emp sal:%g" %(self.eid, self.ename, self.sal))

e1=Emp(101,'smith',100)
e1.display()

e2=Emp(102,'David',200)
e2.display()


################### Example16: __str__()

###Case1
class MyClass:
    pass

c=MyClass()
print(c)  # <__main__.MyClass object at 0x01EB6630>


### Case2
class MyClass:
    def __str__(self):
        return "im pavan"

c=MyClass()
print(c)  # im pavan


## Case3
class MyClass:
    def __str__(self):
        return 10   # Only returns string

c=MyClass()
print(c)  # TypeError: __str__ returned non-string (type int)

################### Example17: printing data using referene variable (__str__())
class Emp:
    def __init__(self,eid,ename,sal):
        self.eid=eid
        self.ename=ename
        self.sal=sal
    def __str__(self):
        return("emp id:{} emp name:{}  emp sal:{}".format(self.eid,self.ename,self.sal))

e1=Emp(101,'smith',100)
print(e1)


###########Example 18 : __delete__

# __delete__ : Executes when we distroy object

class MyClass:
    def __del__(self):
        print("destroyed")

c1=MyClass();
c2=MyClass();

del c1
del c2


















			


