#########  Example:1

def sum(*args):
    s = 0
    for i in args:
        s += i
    print("sum is", s)

sum(1, 2, 3)
sum(1, 2, 3, 4, 5, 7)
sum(1, 2, 3, 4, 5, 7, 8, 9, 10)
sum()



#########  Example:2

def my_three(a, b, c):
    print(a, b, c)

args = [1, 2, 3]
my_three(*args)  # here list is broken into three elements

#Note: This works only when number of argument is same as number of elements in the iterable variable.



#########  Example:3

def my_three(a, b, c):
    print(a, b, c)

a = {'a': "one", 'b': "two", 'c': "three"}
my_three(**a)


#########  Example:4

def my_func(**kwargs):
    for i, j in kwargs.items():
        print(i, j)


my_func(name='tim', sport='football', roll=10)
