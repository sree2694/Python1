#Encapsulation
#------------------

######### Example1: private variables can be access only within the method

class myClass:
    __a=10
    def disp(self):
        print(self.__a) #Able to access private variable witin the class

obj=myClass()
obj.disp() # Displays value of a which is private

print(myClass.__a) # cannot access outside of class, #AttributeError: type object 'myClass' has no attribute '__a'


######### Example2: private methods can be access only within the method

class myClass:
    def __disp1(self):   # private method
        print("This is display1 method")
    def disp2(self):   # Normal method
        print("This is display2 method")
        self.__disp1()

obj=myClass()
obj.disp2() #Calling normal method

obj.disp1() # Cannot access private methods from outside of class

######### Example3: We can access private varaibles outside if class indirectly using methods

class myClass:
    __empid=101

    def getempid(self,eid):
        self.__empid=eid
    def disempid(self):
        print(self.__empid)

obj=myClass()
#print(obj.__empid) # Cannot access private variable directly

obj.disempid() # We can access private variable indirectly using method

obj.getempid(102) #We can change private variable value indirectly using method
obj.disempid() # We can access private variable indirectly using method

#------------------------------------------------------------------------------


######### Example4: Every method Create different objects - this is the problem(Solution is explained in next example)

class A:
    num1, num2=10,20

class B:
    def sum(self):
        a=A()
        print(a.num1+a.num2)
    def mul(self):
        a=A()
        print(a.num1 * a.num2)

b=B()
b.sum() #30
b.mul() #200


######### Example5: One time create a object at class Level and use in multiple methods- Solution

class A:
    num1, num2=10,20

class B:
    a = A()
    def sum(self):
       print(self.a.num1+self.a.num2)
    def mul(self):
      print(self.a.num1 * self.a.num2)

b=B()
b.sum() #30
b.mul() #200








