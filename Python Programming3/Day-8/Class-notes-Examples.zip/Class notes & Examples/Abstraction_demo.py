##################### Example1:

from abc import ABC,abstractmethod

class A(ABC):   # abstract class
    @abstractmethod      # qualifier required
    def display(self):
       pass

class B(A):
    def display(self):
        print("welcome to python")

#obj1=A() # In correct. TypeError: Can't instantiate abstract class A with abstract methods display
#obj1.display()# Error

obj2=B()
obj2.display()

##################### Example2:

from abc import ABC,abstractmethod

class Animal(ABC):
    @abstractmethod
    def eat(self):
        pass

class Tiger(Animal):
    def eat(self):
        print("eating NonVeg")

class Cow(Animal):
    def eat(self):
        print("eating Veg")

t=Tiger()
t.eat() #eating NonVeg

c=Cow()
c.eat() #eating Veg


##################### Example3
from abc import ABC,abstractmethod

class X(ABC):
    @abstractmethod
    def m1(self):
        pass

    @abstractmethod
    def m2(self):
        pass

class Y(X):  # Y is treated as Abstract bcoz m2() is not implemented
    def m1(self):
        print("This is m1")

class Z(Y):  # Z is extended from Y & impleted m2(), so we can create object
    def m2(self):
        print("This is m2")
y=Y() #TypeError: Can't instantiate abstract class Y with abstract methods m2
y.m1()# incorrect

z=Z()
z.m1()
z.m2()

############## Example 4  : Class with constuctor along with abstract methods

from abc import ABC,abstractmethod

class Cal(ABC):
    def __init__(self,value):   # Constructor
        self.value=value

    @abstractmethod
    def add(self):
        pass
    @abstractmethod
    def sub(self):
        pass

class C(Cal):
    def add(self):
        print(self.value+100)
    def sub(self):
        print(self.value - 10)

c=C(100)
c.add() # 200
c.sub() #90








