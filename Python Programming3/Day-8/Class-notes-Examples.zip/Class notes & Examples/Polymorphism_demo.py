######### Example1: Overriding a variable

class Parent:
    name="scott"

class Child(Parent):
    #name="David"
    pass

obj=Child()
print(obj.name)

######### Example2: Overriding Methods with Hirarchy inheritance

class Bank:
    def rateOfInterest(self):
        return 0

class ICICI(Bank):
    def rateOfInterest(self):
        return 10.5

class AXIS(Bank):
    def rateOfInterest(self):
        return 11.5

icici=ICICI()
print(icici.rateOfInterest())

axis=AXIS()
print(axis.rateOfInterest())

############Example3: Overriding Methods with Multi level inheritance
class C1:
    def m1(self):
        print("this is m1 from C1")

class C2(C1):
    def m1(self):
        print("this is m1 from C2")


class C3(C2):
    def m1(self):
        print("this is m1 from C3")

obj=C3()
obj.m1()

######### Example4: Overloading Methods

class Human:
    def sayHello(self, name=None):
        if name is not None:
            print('Hello ' + name)
        else:
            print('Hello')

# Create instance
obj = Human()

# Call the method
obj.sayHello()  #Hello

# Call the method with a parameter
obj.sayHello('Scott') #Hello Scott


######### Example4: Overloading Methods

class Bird:
    def fly(self,name=None):
        if name == "parot":
            print("Can fly")
        if name=="penguine":
            print('Cannot fly')
        if name is None:
            print('No Input')

# Create instance
obj = Bird()

obj.fly('parot')
obj.fly('penguine')
obj.fly()