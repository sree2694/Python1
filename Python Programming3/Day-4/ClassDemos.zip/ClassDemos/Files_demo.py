#Writing data to the file

f = open('C:\DemoFiles\myfile.txt', 'w')    # open file for writing
f.write('this first line\n')   # write a line to the file
f.write('this second line\n')  # write one more line to the file
f.close()                      # close the file


#Reading all the data at once.
f = open('C:\DemoFiles\myfile.txt', 'r')
print(f.read()) # read entire content of file at once
f.close()

#Reading all lines as an array.
file=open("C:\DemoFiles\myfile.txt", "r")
print(file.readlines()) # read entire content of file at once in array format ['THIS IS MY FIRST LINE\n', 'THIS IS MY SECOND LINE\n']
file.close()

#Reading only one line.
f = open('C:\DemoFiles\myfile.txt', 'r')
print(f.readline()) # read the first line
f.close()

#Appending data
f = open('C:\DemoFiles\myfile.txt', 'a')
f.write("this is third line\n")
f.close()

#Looping through the data using for loop
f = open('C:\DemoFiles\myfile.txt', 'r')
for line in f:
    print(line)
f.close()



