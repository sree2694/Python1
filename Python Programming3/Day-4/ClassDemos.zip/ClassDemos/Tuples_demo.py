##############Creating a tuple##############

t1 = ()  # creates an empty tuple with no data
t2 = (11, 22, 33)
t3 = tuple([1, 2, 3, 4, 4])  # tuple from array
t4 = tuple("abc")  # tuple from string

print(t1)
print(t2)
print(t3)
print(t4)

#########Tuples functions#################
t1 = (1, 12, 55, 12, 81)

print(min(t1)) #1
print(max(t1)) # 81
print(sum(t1)) #161
print(len(t1)) #5


###Iterating through tuples###############
t = (11,22,33,44,55)

for i in t:
    print(i, end=" ") #11 22 33 44 55 
	
##########Slicing ###############
t = (11,22,33,44,55)
print(t[0:2]) #(11,22)
print(t[2:4]) #(11,22)	



##########in  and not in  operator###########
t = (11,22,33,44,55)
print(22 in t) #True
print(22 not in t) #False





