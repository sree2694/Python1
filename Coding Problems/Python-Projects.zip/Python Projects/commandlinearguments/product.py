import sys

lst = sys.argv
print("Product is:",int(lst[1])*int(lst[2]))