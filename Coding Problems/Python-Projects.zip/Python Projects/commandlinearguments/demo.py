import sys

lst=sys.argv
for i in lst:print(i)

print(len(lst))

print(lst[0])