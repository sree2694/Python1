l= lambda x: 'YES' if x%2==0 else 'NO'
print(l(10))
print(l(9))
