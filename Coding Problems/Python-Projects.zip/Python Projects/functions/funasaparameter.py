def display(fun):
    return "Hello "+fun

def name():
    return "Bharath"

print(display(name()))