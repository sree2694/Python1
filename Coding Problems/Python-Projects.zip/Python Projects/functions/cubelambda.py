'''def cube(n):
    return n**3

print(cube(2)) '''

f = lambda n:n**3
print(f(2))