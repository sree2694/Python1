def average(a=10,b=20):
    print(a)
    print(b)
    return (a+b)/2

print(average(a=30))
