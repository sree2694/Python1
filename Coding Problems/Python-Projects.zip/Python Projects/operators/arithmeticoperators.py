a,b=10,5

print('Addition: ',a+b)
print('Subtraction: ',a-b)
print('Mul: ',a*b)
print('Div: ',a/b)
print('Mod: ',a%b)
print('Pow: ',a**b)
print('Floor Div: ',a//b)