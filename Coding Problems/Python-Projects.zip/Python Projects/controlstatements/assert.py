x=int(input("Enter a number greater than 10"))
assert x>10, "Wrong number entered"
print("U Entered",x)