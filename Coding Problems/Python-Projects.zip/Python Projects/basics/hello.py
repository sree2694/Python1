''' Author is Bharath Thippireddy
Create On Oct 15th 2017'''
#This is my first python program
print('Python is easy!!')