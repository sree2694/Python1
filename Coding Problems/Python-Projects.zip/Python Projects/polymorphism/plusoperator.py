x = 10
y=20

print(x+y)

s1 = "Hello"
s2 = " How are you "

print(s1+s2)

l1 = [1,2,3]
l2=[4,5,6]
print(l1+l2)