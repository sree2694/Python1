studentid = int(input("Enter Student Id"))
name = input("Enter Student Name")
marks = float(input("Enter marks scored"))

print("ID:",studentid,"Name:",name,"Marks:",marks)