a,b,c=[int(x) for x in input("Enter three integer numbers").split()]
average = (a+b+c)/3
print("Average of the three numbers is:",average)