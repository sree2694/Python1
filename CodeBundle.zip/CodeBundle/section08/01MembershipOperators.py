
str1 = 'Hello World!'

print('H' in str1)
print('hello' in str1)
print('Hello' in str1)

list1 = [ 1, 2, 3, 4 ]

print( 1 in list1)
print( 5 in list1)
