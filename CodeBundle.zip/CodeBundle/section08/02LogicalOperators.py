x = 2
y = 4

print((x > y) and (x < 0))
print((y > x) or (y < 0))
print(not (x > y))
