a = 46
b = 86

print( a & b )
print( a | b )
print( a ^ b )
print( ~a )
print( a << 2 )
print( a >> 2 )
