def printHello():
    print("Hello World!")

def printHello1():
    first_name = input("Please enter your name : ")
    print("Hello {0}".format(first_name))

printHello()
printHello1()
