def team( *members ):

    print("My team has following members :")
    for name in members:
        print( name )

team('Ashwin', 'Jane', 'Thor', 'Tony')
