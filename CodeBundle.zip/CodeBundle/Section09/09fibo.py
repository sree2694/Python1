a = 0
b = 1

i = 0

while i < 100:
    print(a)
    c = a + b
    a = b
    b = c
    i = i + 1
