
for i in range(5):
    if i == 3:
        continue
    print(i)

for i in range(5):
    if i == 3:
        break
    print(i)
