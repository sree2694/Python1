
for i in range(5):
    print(i)


for i in range(5, 10):
    print(i)

for i in range(0, 10, 2):
    print(i)
