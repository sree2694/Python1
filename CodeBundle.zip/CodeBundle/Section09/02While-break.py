i = 0

while i < 10:
    print(i)
    if i == 6:
        break
    i = i + 1
