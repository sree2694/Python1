list1 = [ 2, 4, 5, 1 ]

for i in list1:
    print(i)
