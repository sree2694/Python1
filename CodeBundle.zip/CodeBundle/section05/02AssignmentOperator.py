a = 10

b = a

print(a)
print(b)

a = b = 20

print(a)
print(b)


a, b = 30, 40
print(a)
print(b)
