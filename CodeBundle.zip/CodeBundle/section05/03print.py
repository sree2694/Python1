print("Hello World!")


print('Hello World!')

pi = 3.14

print(pi)

print('Value of Pi is ', pi)

print('Value of Pi is %f' % pi)

print('Value of Pi is {}'.format(pi))

first_name = 'Ashwin'
last_name = 'Pajankar'

print('My name is %s %s.' % (first_name, last_name))

print('My name is {} {}.'.format(first_name, last_name))

print('My name is {0} {1}.'.format(first_name, last_name))

print('My name is {1} {0}.'.format(first_name, last_name))























