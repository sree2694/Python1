print("This statement will be executed!")

#print("This statement must not be executed!")
# # stands for comment

'''
This is a multiline comment
Test String
'''

"""
This is a multiline comment
Test String
"""
