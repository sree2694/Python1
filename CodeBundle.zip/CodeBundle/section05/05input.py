first_name = input("What is your name? ")

print(first_name)

print("Hello {0}.".format(first_name))

age = int(input("What is your age? "))

print(age)

print("I am {0} years old.".format(age))
