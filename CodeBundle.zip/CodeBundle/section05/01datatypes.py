a = 10
print(a)

a = 0b10
print(a)

a = 0B10
print(a)

a = 0o10
print(a)

a = 0O10
print(a)

a = 0x10
print(a)

a = 0X10
print(a)

pi = 3.14
print(pi)

pi = .314e1
print(pi)

comp = 3 + 4j
print(comp)

cond1 = True
cond2 = False

print(cond1)
print(cond2)


str1 = 'This is a String'
str2 = "This is a string too"
str3 = """ This is a
multiline string"""

print(str1)
print(str2)
print(str3)










































