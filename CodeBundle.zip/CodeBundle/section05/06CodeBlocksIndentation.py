a = 10

if a < 0:
    print("This is within if block")
    print("Code block ends here")
    print("a is greater than zero")
    if( a < -5):
        print("test")
