
a = 4
b = 2
c = 3

# Arithmetic Operations precedence

print (a + b * c)
print ((a + b) * c)
print ( a + (b * c))

# Associativity

print(a - b - c)
print((a - b) - c)
print(a - (b - c))

# Unary Minus

print(-a + b )
print(- ( a + b ))

a += 1
print(a)
a -= 1
print(a)





