# Assignment Statement

a = 4
b = 2

# Arithmetic Operations

c = a + b
print(c)

c = a - b
print(c)

c = a / b
print(c)

c = a * b
print(c)

c = a % b
print(c)

c = a ** b
print(c)

c = - b
print(c)













