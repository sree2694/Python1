print(abs(10))
print(abs(-10))

print(bin(10))
print(bool(10))
print(bool(-10))

print(hex(10))
print(oct(10))

print(callable(print))

print(complex(3, 5))
print(help(print))
