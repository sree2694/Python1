a = 3
b = 2

if a > b:
    print("a is greater than b")
else:
    print("b is greater than a")
