a = 4
b = 2

# Boolean Expressions

print(a == b)
print(a < b)
print(a > b)
print(a <= b)
print(a >= b)
print(a != b)
