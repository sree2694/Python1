a = 1
b = 2

if a > b:
    print("a is greater than b")
    print("This is within if statement")
print("This is outside the if statement")
